import{d as e,o as r,c as a}from"./element-plus.34e6be4b.js";var n=e({name:"404"});n.render=function(e,n,t,l,o,s){return r(),a("div",null,"404 page")};export default n;
//# sourceMappingURL=404.c16c497e.js.map
