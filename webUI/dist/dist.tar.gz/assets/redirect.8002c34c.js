import{a as e,c as a}from"./index.b1483519.js";import{d as t,h as r}from"./element-plus.34e6be4b.js";var p=t({name:"Redirect",setup(){const t=e(),r=a(),{pathMatch:p}=t.params;r.replace({path:"string"==typeof p?`/${p}`:`/${p.join("/")}`})},render:()=>r("div")});export default p;
//# sourceMappingURL=redirect.8002c34c.js.map
