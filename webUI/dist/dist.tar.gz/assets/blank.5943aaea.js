import{d as e,r,o as a,c as t,m as n}from"./element-plus.34e6be4b.js";var s=e({name:"LayoutBlank",setup:()=>({})});s.render=function(e,s,o,u,l,m){const d=r("router-view");return a(),t("div",null,[n(d)])};export default s;
//# sourceMappingURL=blank.5943aaea.js.map
