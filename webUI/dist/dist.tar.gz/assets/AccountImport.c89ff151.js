import{d as e,e as t,o as n,c as a,m as s}from"./element-plus.34e6be4b.js";var p=e({name:"AccountImport",setup:()=>({input:t("")})});const r=s("p",{style:{height:"1500px"}},"高度超出，滚动条测试",-1),u=s("span",null,"aa",-1);p.render=function(e,t,s,p,l,o){return n(),a("div",null,[r,u])};export default p;
//# sourceMappingURL=AccountImport.c89ff151.js.map
